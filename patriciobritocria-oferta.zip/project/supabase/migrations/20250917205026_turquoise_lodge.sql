/*
  # Allow anonymous lead insertion

  1. Security Changes
    - Drop existing restrictive INSERT policy for leads
    - Create new policy allowing anonymous users to insert leads
    - Ensure anon role has proper permissions

  This migration fixes the 403 error when anonymous users try to submit emails
  on the landing page by allowing INSERT operations for the anon role.
*/

-- Drop the existing INSERT policy if it exists
DROP POLICY IF EXISTS "Allow anonymous lead insertion" ON leads;
DROP POLICY IF EXISTS "Users can insert leads" ON leads;

-- Create a new policy that explicitly allows anonymous users to insert leads
CREATE POLICY "Allow anonymous lead insertion" 
ON leads 
FOR INSERT 
TO anon 
WITH CHECK (true);

-- Also allow authenticated users to insert leads
CREATE POLICY "Allow authenticated lead insertion" 
ON leads 
FOR INSERT 
TO authenticated 
WITH CHECK (true);

-- Ensure the anon role has INSERT permission on the leads table
GRANT INSERT ON leads TO anon;
GRANT INSERT ON leads TO authenticated;

-- Verify RLS is enabled on the leads table
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;