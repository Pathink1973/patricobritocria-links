/*
  # Add short_code column to admin_settings

  1. Changes
    - Add `short_code` column to `admin_settings` table
    - Make it unique to prevent conflicts
    - Add index for better performance on lookups

  2. Security
    - No changes to RLS policies needed
*/

-- Add short_code column to admin_settings table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'admin_settings' AND column_name = 'short_code'
  ) THEN
    ALTER TABLE admin_settings ADD COLUMN short_code text UNIQUE;
  END IF;
END $$;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_admin_settings_short_code ON admin_settings(short_code);