/*
  # Setup Storage Bucket for Content Files

  1. Storage Configuration
    - Create 'content' bucket if it doesn't exist
    - Make bucket public for file downloads
    - Set up RLS policies for file access

  2. Security
    - Allow public read access to uploaded files
    - Restrict upload/delete to authenticated users only
*/

-- Create the content bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('content', 'content', true)
ON CONFLICT (id) DO UPDATE SET public = true;

-- Enable RLS on storage.objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Policy to allow public read access to files in the content bucket
CREATE POLICY "Public read access for content bucket"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'content');

-- Policy to allow authenticated users to upload files to content bucket
CREATE POLICY "Authenticated users can upload to content bucket"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'content');

-- Policy to allow authenticated users to update their own files
CREATE POLICY "Authenticated users can update own files in content bucket"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'content' AND auth.uid()::text = owner);

-- Policy to allow authenticated users to delete their own files
CREATE POLICY "Authenticated users can delete own files in content bucket"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'content' AND auth.uid()::text = owner);