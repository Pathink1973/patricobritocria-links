/*
  # Fix anonymous user permissions for leads table

  1. Grant Permissions
    - Grant INSERT permission to anon role on leads table
    - Grant SELECT permission to anon role on admin_settings table (needed for the foreign key relationship)
  
  2. Security
    - Maintains existing RLS policies
    - Only grants minimal necessary permissions
*/

-- Grant INSERT permission to anon role on leads table
GRANT INSERT ON public.leads TO anon;

-- Grant SELECT permission to anon role on admin_settings table
-- This is needed because the leads table has a foreign key to admin_settings
-- and Supabase needs to verify the foreign key constraint
GRANT SELECT ON public.admin_settings TO anon;

-- Ensure RLS is enabled (should already be enabled, but just to be safe)
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_settings ENABLE ROW LEVEL SECURITY;