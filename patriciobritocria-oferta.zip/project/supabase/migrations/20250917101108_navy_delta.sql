/*
  # Create admin_settings and leads tables

  1. New Tables
    - `admin_settings`
      - `id` (uuid, primary key) 
      - `cover_image_url` (text, nullable) - URL for cover image
      - `logo_url` (text, nullable) - URL for logo image
      - `title` (text, nullable) - Main title for landing page
      - `subtitle` (text, nullable) - Subtitle for landing page
      - `description` (text, nullable) - Description text
      - `checklist_item` (text, nullable) - Checklist item text
      - `file_url` (text, nullable) - URL of file to be shared
      - `instagram_url` (text, nullable) - Instagram profile URL
      - `created_at` (timestamptz) - Created timestamp
      - `updated_at` (timestamptz) - Updated timestamp

    - `leads` 
      - `id` (uuid, primary key)
      - `email` (text, unique per settings) - User email
      - `settings_id` (uuid, foreign key) - Reference to admin_settings
      - `created_at` (timestamptz) - Created timestamp

  2. Security
    - Enable RLS on both tables
    - Admin can read/write admin_settings
    - Admin can read leads
    - Anonymous users can read admin_settings (for public pages)
    - Anonymous users can insert into leads (for email capture)
*/

-- Create admin_settings table
CREATE TABLE IF NOT EXISTS admin_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cover_image_url text,
  logo_url text,
  title text,
  subtitle text,
  description text,
  checklist_item text,
  file_url text,
  instagram_url text DEFAULT 'https://www.instagram.com/patriciobrito.cria',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create leads table
CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  settings_id uuid NOT NULL REFERENCES admin_settings(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(email, settings_id)
);

-- Enable RLS
ALTER TABLE admin_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

-- Policies for admin_settings
CREATE POLICY "Allow anonymous read access to admin_settings"
  ON admin_settings
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow authenticated users full access to admin_settings"
  ON admin_settings
  FOR ALL
  TO authenticated
  USING (true);

-- Policies for leads
CREATE POLICY "Allow anonymous users to insert leads"
  ON leads
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to read leads"
  ON leads
  FOR SELECT
  TO authenticated
  USING (true);

-- Create storage bucket for content uploads
INSERT INTO storage.buckets (id, name, public) 
VALUES ('content', 'content', true)
ON CONFLICT (id) DO NOTHING;

-- Allow public access to content bucket
CREATE POLICY "Allow public uploads to content bucket"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'content');

CREATE POLICY "Allow public access to content bucket"
  ON storage.objects
  FOR SELECT
  TO public
  USING (bucket_id = 'content');

CREATE POLICY "Allow authenticated users to update content bucket"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'content');

CREATE POLICY "Allow authenticated users to delete from content bucket"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (bucket_id = 'content');