/*
  # Add support for multiple content pages and archiving

  1. Schema Changes
    - Add `user_id` column to `admin_settings` to link content to specific administrators
    - Add `is_active` column to `admin_settings` to support archiving
    - Add `name` column to `admin_settings` for better content identification
    - Update RLS policies to ensure users only access their own content

  2. Security
    - Update RLS policies for `admin_settings` to filter by `user_id`
    - Ensure `leads` table maintains proper access control
*/

-- Add new columns to admin_settings
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'admin_settings' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE admin_settings ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'admin_settings' AND column_name = 'is_active'
  ) THEN
    ALTER TABLE admin_settings ADD COLUMN is_active boolean DEFAULT true;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'admin_settings' AND column_name = 'name'
  ) THEN
    ALTER TABLE admin_settings ADD COLUMN name text DEFAULT 'Conteúdo sem nome';
  END IF;
END $$;

-- Update existing records to have a user_id (for migration purposes)
-- This will need to be handled manually for existing data

-- Drop existing policies
DROP POLICY IF EXISTS "Allow anonymous read access to admin_settings" ON admin_settings;
DROP POLICY IF EXISTS "Allow authenticated users full access to admin_settings" ON admin_settings;

-- Create new RLS policies for admin_settings
CREATE POLICY "Users can read their own admin_settings"
  ON admin_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own admin_settings"
  ON admin_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own admin_settings"
  ON admin_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own admin_settings"
  ON admin_settings
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Allow anonymous users to read active admin_settings for public landing pages
CREATE POLICY "Allow anonymous read access to active admin_settings"
  ON admin_settings
  FOR SELECT
  TO anon
  USING (is_active = true);

-- Update leads policies to ensure proper access control
DROP POLICY IF EXISTS "Allow authenticated users to read leads" ON leads;

CREATE POLICY "Users can read leads for their own content"
  ON leads
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_settings 
      WHERE admin_settings.id = leads.settings_id 
      AND admin_settings.user_id = auth.uid()
    )
  );