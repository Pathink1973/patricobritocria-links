/*
  # Fix RLS policies for anonymous lead insertion

  1. Security Changes
    - Update the leads table RLS policy to allow anonymous users to insert leads
    - Ensure anonymous users can insert leads but not read other users' leads
    - Keep authenticated users able to read their own leads

  2. Changes
    - Drop existing restrictive policy
    - Create new policy allowing anonymous inserts
    - Maintain security for reading leads
*/

-- Drop existing policies that might be blocking anonymous access
DROP POLICY IF EXISTS "Allow anonymous users to insert leads" ON leads;
DROP POLICY IF EXISTS "Users can read leads for their own content" ON leads;

-- Allow anonymous users to insert leads
CREATE POLICY "Allow anonymous lead insertion"
  ON leads
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow authenticated users to read leads for their own content
CREATE POLICY "Authenticated users can read own leads"
  ON leads
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_settings
      WHERE admin_settings.id = leads.settings_id
      AND admin_settings.user_id = auth.uid()
    )
  );

-- Ensure RLS is enabled
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;