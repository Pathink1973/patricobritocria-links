import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate, useParams } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'
import { LoginForm } from './components/Auth/LoginForm'
import { Dashboard } from './components/Admin/Dashboard'
import { LandingPage } from './components/Public/LandingPage'

function App() {
  const { user, loading, signIn, signOut, signUp } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
      </div>
    )
  }

  return (
    <Router>
      <Routes>
        {/* Admin Routes */}
        <Route
          path="/admin"
          element={
            user ? (
              <Dashboard onSignOut={signOut} />
            ) : (
              <LoginForm onLogin={signIn} onSignUp={signUp} />
            )
          }
        />

        {/* Public Landing Page Route */}
        <Route
          path="/download/oferta/:shortCode"
          element={<LandingPageRoute />}
        />

        {/* Default redirect to admin */}
        <Route
          path="/"
          element={<Navigate to="/admin" replace />}
        />
      </Routes>
    </Router>
  )
}

function LandingPageRoute() {
  const { shortCode } = useParams<{ shortCode: string }>()
  
  if (!shortCode || shortCode === 'null') {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Página não encontrada</h1>
          <p className="text-gray-600">Link inválido ou expirado.</p>
        </div>
      </div>
    )
  }
  
  return <LandingPage shortCode={shortCode} />
}

export default App