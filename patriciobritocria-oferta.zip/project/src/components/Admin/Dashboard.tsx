import React, { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { LogOut, Upload, Settings, Users, ExternalLink, Copy, Check, Plus, Archive, Edit3, Eye, ArchiveRestore, Trash } from 'lucide-react'
import { FileUpload } from './FileUpload'
import { LeadsList } from './LeadsList'
import { useAuth } from '../../hooks/useAuth'

interface AdminSettings {
  id: string
  user_id: string
  name: string
  is_active: boolean
  short_code: string | null
  cover_image_url: string | null
  logo_url: string | null
  title: string | null
  subtitle: string | null
  description: string | null
  checklist_item: string | null
  file_url: string | null
  instagram_url: string | null
}

interface DashboardProps {
  onSignOut: () => void
}

export function Dashboard({ onSignOut }: DashboardProps) {
  const { user } = useAuth()
  const [allSettings, setAllSettings] = useState<AdminSettings[]>([])
  const [currentSettings, setCurrentSettings] = useState<AdminSettings | null>(null)
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState<'list' | 'content' | 'leads'>('list')
  const [copied, setCopied] = useState(false)

  const [formData, setFormData] = useState({
    name: '',
    title: '',
    subtitle: '',
    description: '',
    checklist_item: '',
    file_url: '',
    instagram_url: 'https://www.instagram.com/patriciobrito.cria'
  })

  // Function to generate a unique 6-character alphanumeric code
  const generateShortCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    let result = ''
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  // Function to check if short code is unique
  const isShortCodeUnique = async (shortCode: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase
        .from('admin_settings')
        .select('id')
        .eq('short_code', shortCode)
        .limit(1)

      if (error) {
        console.error('Error checking short code uniqueness:', error)
        return false
      }

      // If data is null or empty array, code is unique
      return !data || data.length === 0
    } catch (error) {
      console.error('Error checking short code uniqueness:', error)
      return false
    }
  }

  // Function to generate a unique short code
  const generateUniqueShortCode = async (): Promise<string> => {
    let shortCode = generateShortCode()
    let attempts = 0
    const maxAttempts = 10

    while (attempts < maxAttempts) {
      const isUnique = await isShortCodeUnique(shortCode)
      if (isUnique) {
        return shortCode
      }
      shortCode = generateShortCode()
      attempts++
    }

    // If we can't generate a unique code after 10 attempts, add timestamp
    return generateShortCode() + Date.now().toString().slice(-2)
  }
  
  useEffect(() => {
    if (user?.id) {
      loadAllSettings()
    }
  }, [user?.id])

  const loadAllSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('admin_settings')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })

      if (error) {
        console.error('Error loading settings:', error)
        return
      }

      setAllSettings(data || [])
    } catch (error) {
      console.error('Error loading settings:', error)
    }
  }

  const selectSettings = (settings: AdminSettings) => {
    setCurrentSettings(settings)
    setFormData({
      name: settings.name || '',
      title: settings.title || '',
      subtitle: settings.subtitle || '',
      description: settings.description || '',
      checklist_item: settings.checklist_item || '',
      file_url: settings.file_url || '',
      instagram_url: settings.instagram_url || 'https://www.instagram.com/patriciobrito.cria'
    })
    setActiveTab('content')
  }

  const createNewSettings = async () => {
    if (!user) return
    
    setLoading(true)
    try {
      const shortCode = await generateUniqueShortCode()
      
      const newSettings = {
        user_id: user.id,
        name: 'Novo Conteúdo',
        short_code: shortCode,
        title: '',
        subtitle: '',
        description: '',
        checklist_item: '',
        file_url: '',
        instagram_url: 'https://www.instagram.com/patriciobrito.cria',
        is_active: true
      }

      const { data, error } = await supabase
        .from('admin_settings')
        .insert(newSettings)
        .select()
        .single()

      if (error) throw error

      await loadAllSettings()
      selectSettings(data)
    } catch (error) {
      console.error('Error creating new settings:', error)
      alert('Erro ao criar novo conteúdo')
    } finally {
      setLoading(false)
    }
  }

  const saveSettings = async () => {
    if (!currentSettings) return
    
    setLoading(true)
    try {
      const settingsData = {
        ...formData,
        cover_image_url: currentSettings.cover_image_url,
        logo_url: currentSettings.logo_url,
        updated_at: new Date().toISOString()
      }

      const { data, error } = await supabase
        .from('admin_settings')
        .update(settingsData)
        .eq('id', currentSettings.id)
        .select()
        .single()

      if (error) throw error

      setCurrentSettings(data)
      await loadAllSettings()
      alert('Configurações salvas com sucesso!')
    } catch (error) {
      console.error('Error saving settings:', error)
      alert('Erro ao salvar configurações')
    } finally {
      setLoading(false)
    }
  }

  const handleImageUpload = async (type: 'cover' | 'logo', url: string) => {
    if (!currentSettings) return
    
    try {
      const updateData = type === 'cover' 
        ? { cover_image_url: url }
        : { logo_url: url }

      const { data, error } = await supabase
        .from('admin_settings')
        .update({
          ...updateData,
          updated_at: new Date().toISOString()
        })
        .eq('id', currentSettings.id)
        .select()
        .single()

      if (error) throw error

      setCurrentSettings(prev => prev ? { ...prev, ...updateData } : null)
      await loadAllSettings()
      alert(`${type === 'cover' ? 'Capa' : 'Logo'} enviado com sucesso!`)
    } catch (error) {
      console.error('Error updating image:', error)
      alert('Erro ao enviar imagem')
    }
  }

  const handleFileUpload = async (url: string) => {
    if (!currentSettings) return
    
    try {
      const { data, error } = await supabase
        .from('admin_settings')
        .update({
          file_url: url,
          updated_at: new Date().toISOString()
        })
        .eq('id', currentSettings.id)
        .select()
        .single()

      if (error) throw error

      setCurrentSettings(prev => prev ? { ...prev, file_url: url } : null)
      await loadAllSettings()
      alert('Ficheiro enviado com sucesso!')
    } catch (error) {
      console.error('Error updating file:', error)
      alert('Erro ao enviar ficheiro')
    }
  }

  const copyShareableUrl = () => {
    if (currentSettings?.short_code) {
      const url = `${window.location.origin}/download/oferta/${currentSettings.short_code}`
      navigator.clipboard.writeText(url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleArchiveStatus = async (settingsId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('admin_settings')
        .update({ 
          is_active: !currentStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', settingsId)

      if (error) throw error

      await loadAllSettings()
      if (currentSettings?.id === settingsId) {
        setCurrentSettings(prev => prev ? { ...prev, is_active: !currentStatus } : null)
      }
    } catch (error) {
      console.error('Error toggling archive status:', error)
      alert('Erro ao alterar status do conteúdo')
    }
  }

  const deleteSettings = async (settingsId: string, settingsName: string) => {
    const confirmMessage = `Tem certeza que deseja apagar permanentemente o conteúdo "${settingsName}"?\n\nEsta ação não pode ser desfeita e todos os leads associados também serão removidos.`
    
    if (!window.confirm(confirmMessage)) {
      return
    }

    try {
      const { error } = await supabase
        .from('admin_settings')
        .delete()
        .eq('id', settingsId)

      if (error) throw error

      // If the deleted content was currently selected, clear it
      if (currentSettings?.id === settingsId) {
        setCurrentSettings(null)
        setActiveTab('list')
      }

      await loadAllSettings()
      alert('Conteúdo apagado com sucesso!')
    } catch (error) {
      console.error('Error deleting settings:', error)
      alert('Erro ao apagar conteúdo')
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Dashboard Admin</h1>
              <p className="text-gray-600">Gerencie seus conteúdos e leads</p>
            </div>
            <button
              onClick={onSignOut}
              className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-8">
          <button
            onClick={() => setActiveTab('list')}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-medium transition-colors ${
              activeTab === 'list'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Settings className="w-4 h-4" />
            Meus Conteúdos
          </button>
          <button
            onClick={() => setActiveTab('content')}
            disabled={!currentSettings}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-medium transition-colors ${
              activeTab === 'content'
                ? 'bg-white text-gray-900 shadow-sm' 
                : !currentSettings 
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Edit3 className="w-4 h-4" />
            Editar Conteúdo
          </button>
          <button
            onClick={() => setActiveTab('leads')}
            disabled={!currentSettings}
            className={`flex items-center gap-2 px-4 py-2 rounded-md font-medium transition-colors ${
              activeTab === 'leads'
                ? 'bg-white text-gray-900 shadow-sm' 
                : !currentSettings 
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Users className="w-4 h-4" />
            Leads
          </button>
        </div>

        {activeTab === 'list' ? (
          <div className="space-y-6">
            {/* Create New Button */}
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Seus Conteúdos</h2>
              <button
                onClick={createNewSettings}
                disabled={loading}
                className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                Criar Novo Conteúdo
              </button>
            </div>

            {/* Content List */}
            <div className="bg-white rounded-lg shadow">
              {allSettings.length === 0 ? (
                <div className="p-12 text-center">
                  <Settings className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum conteúdo ainda</h3>
                  <p className="text-gray-600 mb-4">
                    Crie seu primeiro conteúdo para começar a captar leads.
                  </p>
                  <button
                    onClick={createNewSettings}
                    disabled={loading}
                    className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white rounded-lg transition-colors mx-auto"
                  >
                    <Plus className="w-4 h-4" />
                    Criar Primeiro Conteúdo
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {allSettings.map((settings) => (
                    <div key={settings.id} className="p-6 hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-medium text-gray-900">
                              {settings.name || 'Conteúdo sem nome'}
                            </h3>
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              settings.is_active 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {settings.is_active ? 'Ativo' : 'Arquivado'}
                            </span>
                          </div>
                          <p className="text-gray-600 mb-2">
                            {settings.title || 'Título não definido'}
                          </p>
                          <p className="text-sm text-gray-500">
                            Criado em {new Date(settings.created_at).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => selectSettings(settings)}
                            className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                          >
                            <Edit3 className="w-4 h-4" />
                            Editar
                          </button>
                          {settings.is_active && (
                            <a
                              href={`/download/oferta/${settings.short_code}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                            >
                              <Eye className="w-4 h-4" />
                              Ver
                            </a>
                          )}
                          <button
                            onClick={() => toggleArchiveStatus(settings.id, settings.is_active)}
                            className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                              settings.is_active
                                ? 'text-orange-600 hover:text-orange-700 hover:bg-orange-50'
                                : 'text-green-600 hover:text-green-700 hover:bg-green-50'
                            }`}
                          >
                            {settings.is_active ? (
                              <>
                                <Archive className="w-4 h-4" />
                                Arquivar
                              </>
                            ) : (
                              <>
                                <ArchiveRestore className="w-4 h-4" />
                                Restaurar
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                      <button
                        onClick={() => deleteSettings(settings.id, settings.name || 'Conteúdo sem nome')}
                        className="flex items-center gap-2 px-3 py-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash className="w-4 h-4" />
                        Apagar
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : activeTab === 'content' && currentSettings ? (
          <div className="space-y-8">
            {/* Shareable URL */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-4">Link para Partilha</h2>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center gap-3">
                  <code className="flex-1 bg-gray-50 px-3 py-2 rounded text-sm">
                    {`${window.location.origin}/download/oferta/${currentSettings.short_code}`}
                  </code>
                  <button
                    onClick={copyShareableUrl}
                    className="flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition-colors"
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    {copied ? 'Copiado!' : 'Copiar'}
                  </button>
                  <a
                    href={`/download/oferta/${currentSettings.short_code}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Abrir
                  </a>
                </div>
              </div>
            </div>

            {/* Image Uploads */}
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold mb-4">Imagem de Capa</h2>
                <FileUpload
                  type="cover"
                  currentUrl={currentSettings.cover_image_url}
                  onUpload={(url) => handleImageUpload('cover', url)}
                />
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold mb-4">Logo</h2>
                <FileUpload
                  type="logo"
                  currentUrl={currentSettings.logo_url}
                  onUpload={(url) => handleImageUpload('logo', url)}
                />
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold mb-4">Ficheiro para Download</h2>
                <FileUpload
                  type="file"
                  currentUrl={currentSettings.file_url}
                  onUpload={handleFileUpload}
                />
              </div>
            </div>

            {/* Content Form */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-6">Conteúdo da Landing Page</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nome do Conteúdo (interno)
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Ex: Campanha R$10k - Janeiro 2025"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Título Principal
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Ex: Os primeiros R$10k com IA e automação"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subtítulo
                  </label>
                  <input
                    type="text"
                    value={formData.subtitle}
                    onChange={(e) => setFormData(prev => ({ ...prev, subtitle: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Ex: com IA e automação"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Descrição
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Aqui você conseguirá baixar todos os conteúdos mostrados na live..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Item de Checklist
                  </label>
                  <input
                    type="text"
                    value={formData.checklist_item}
                    onChange={(e) => setFormData(prev => ({ ...prev, checklist_item: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Ex: Checklist para os R$10k"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    URL do Arquivo para Download (opcional - use o upload acima)
                  </label>
                  <input
                    type="url"
                    value={formData.file_url}
                    onChange={(e) => setFormData(prev => ({ ...prev, file_url: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="https://exemplo.com/ficheiro.pdf (ou use o upload acima)"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Recomendado: Use o upload de ficheiro acima para melhor compatibilidade
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    URL do Instagram
                  </label>
                  <input
                    type="url"
                    value={formData.instagram_url}
                    onChange={(e) => setFormData(prev => ({ ...prev, instagram_url: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="https://www.instagram.com/patriciobrito.cria"
                  />
                </div>

                <button
                  onClick={saveSettings}
                  disabled={loading}
                  className="w-full bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white font-semibold py-3 px-4 rounded-lg transition-colors"
                >
                  {loading ? 'Salvando...' : 'Salvar Configurações'}
                </button>
              </div>
            </div>
          </div>
        ) : (
          currentSettings && <LeadsList settingsId={currentSettings.id} />
        )}
      </div>
    </div>
  )
}