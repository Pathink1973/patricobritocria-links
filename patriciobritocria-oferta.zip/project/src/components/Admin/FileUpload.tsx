import React, { useState } from 'react'
import { Upload, Image as ImageIcon, X, Download } from 'lucide-react'
import { supabase } from '../../lib/supabase'

interface FileUploadProps {
  type: 'cover' | 'logo' | 'file'
  currentUrl: string | null
  onUpload: (url: string) => void
}

export function FileUpload({ type, currentUrl, onUpload }: FileUploadProps) {
  const [uploading, setUploading] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentUrl)

  const uploadFile = async (file: File) => {
    setUploading(true)
    try {
      console.log('=== UPLOAD DEBUG ===')
      console.log('Environment:', import.meta.env.MODE)
      console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL)
      console.log('File details:', {
        name: file.name,
        size: file.size,
        type: file.type
      })
      
      const fileExt = file.name.split('.').pop()
      const timestamp = Date.now()
      const fileName = type === 'file' 
        ? `downloads/file-${timestamp}.${fileExt}`
        : `${type}s/${type}-${timestamp}.${fileExt}`
      const filePath = `uploads/${fileName}`

      console.log('Upload path:', filePath)
      const { error: uploadError } = await supabase.storage
        .from('content')
        .upload(filePath, file)

      if (uploadError) {
        console.error('Upload error:', uploadError)
        throw uploadError
      }

      const { data: urlData } = supabase.storage
        .from('content')
        .getPublicUrl(filePath)

      console.log('Generated URL:', urlData.publicUrl)
      // Verify the file was uploaded successfully
      const { data: fileData, error: checkError } = await supabase.storage
        .from('content')
        .list('uploads', {
          search: fileName
        })

      if (checkError || !fileData || fileData.length === 0) {
        console.error('File verification failed:', { checkError, fileData })
        throw new Error('File upload verification failed')
      }

      console.log('File verified successfully')
      setPreviewUrl(urlData.publicUrl)
      onUpload(urlData.publicUrl)
    } catch (error) {
      console.error('Error uploading file:', error)
      alert(`Erro ao enviar arquivo: ${error.message || 'Erro desconhecido'}`)
    } finally {
      setUploading(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type based on upload type
    if (type !== 'file' && !file.type.startsWith('image/')) {
      alert('Por favor, selecione apenas imagens')
      return
    }

    // Validate file size (max 10MB for files, 5MB for images)
    const maxSize = type === 'file' ? 10 * 1024 * 1024 : 5 * 1024 * 1024
    if (file.size > maxSize) {
      const maxSizeText = type === 'file' ? '10MB' : '5MB'
      alert(`O ficheiro deve ter no máximo ${maxSizeText}`)
      return
    }

    uploadFile(file)
  }

  const removeImage = () => {
    setPreviewUrl(null)
    onUpload('')
  }

  return (
    <div className="space-y-4">
      {previewUrl ? (
        <div className="relative">
          {type === 'file' ? (
            <div className="w-full h-24 bg-blue-50 border-2 border-blue-200 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Download className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <p className="text-sm text-blue-700 font-medium">Ficheiro carregado</p>
                <p className="text-xs text-blue-600">Pronto para download</p>
              </div>
            </div>
          ) : (
            <img
              src={previewUrl}
              alt={`${type} preview`}
              className={`w-full object-cover rounded-lg ${
                type === 'cover' ? 'h-48' : 'h-24'
              }`}
            />
          )}
          <button
            onClick={removeImage}
            className="absolute top-2 right-2 p-1 bg-red-500 hover:bg-red-600 text-white rounded-full transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className={`border-2 border-dashed border-gray-300 rounded-lg ${
          type === 'cover' ? 'h-48' : type === 'file' ? 'h-32' : 'h-24'
        } flex items-center justify-center bg-gray-50`}>
          <div className="text-center">
            {type === 'file' ? (
              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            ) : (
              <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            )}
            <p className="text-sm text-gray-500">
              {type === 'cover' ? 'Imagem de capa' : type === 'logo' ? 'Logo' : 'Ficheiro para download'}
            </p>
          </div>
        </div>
      )}

      <div>
        <label
          htmlFor={`${type}-upload`}
          className={`inline-flex items-center gap-2 px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-lg cursor-pointer transition-colors ${
            uploading ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          <Upload className="w-4 h-4" />
          {uploading ? 'Enviando...' : 'Escolher arquivo'}
        </label>
        <input
          id={`${type}-upload`}
          type="file"
          accept={type === 'file' ? '*/*' : 'image/*'}
          onChange={handleFileChange}
          disabled={uploading}
          className="hidden"
        />
      </div>

      <p className="text-xs text-gray-500">
        {type === 'file' 
          ? 'Todos os formatos aceitos (máx. 10MB)'
          : `Formatos aceitos: JPG, PNG (máx. 5MB)${
              type === 'cover' ? ' - Recomendado: 600x400px' : 
              type === 'logo' ? ' - Recomendado: 200x80px' : ''
            }`
        }
      </p>
    </div>
  )
}