import React, { useState, useEffect } from 'react'
import { Mail, Download, Check, AlertCircle, ArrowRight, Instagram } from 'lucide-react'
import { supabase } from '../../lib/supabase'

interface LandingPageProps {
  shortCode: string
}

interface Settings {
  id: string
  short_code: string | null
  cover_image_url: string | null
  logo_url: string | null
  title: string | null
  subtitle: string | null
  description: string | null
  checklist_item: string | null
  file_url: string | null
  instagram_url: string | null
}

export function LandingPage({ shortCode }: LandingPageProps) {
  const [settings, setSettings] = useState<Settings | null>(null)
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    loadSettings()
  }, [shortCode])

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('admin_settings')
        .select('*')
        .eq('short_code', shortCode)
        .eq('is_active', true)
        .single()

      if (error) {
        console.error('Error loading settings:', error)
        return
      }
      setSettings(data)
    } catch (error) {
      console.error('Error loading settings:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      setError('Por favor, insira um email válido')
      setLoading(false)
      return
    }

    try {
      console.log('=== INSERTING LEAD ===')
      console.log('Email:', email)
      console.log('Settings ID:', settings?.id)
      console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL)
      console.log('Supabase Anon Key:', import.meta.env.VITE_SUPABASE_ANON_KEY ? 'Present' : 'Missing')
      
      const { error } = await supabase
        .from('leads')
        .insert([
          {
            email,
            settings_id: settings.id
          }
        ])

      console.log('Insert result - Error:', error)
      
      if (error) throw error
      console.log('=== LEAD INSERTED SUCCESSFULLY ===')
      setSubmitted(true)
    } catch (error: any) {
      console.error('=== LEAD INSERTION ERROR ===', error)
      console.error('Error details:', {
        message: error.message,
        code: error.code,
        details: error.details,
        hint: error.hint
      })
      if (error.code === '23505') {
        setError('Este email já foi cadastrado')
      } else {
        setError(`Erro ao cadastrar email: ${error.message || 'Erro desconhecido'}`)
      }
    } finally {
      setLoading(false)
    }
  }

  if (!settings) {
    return (
      <div className="min-h-screen bg-orange-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Conteúdo não encontrado</h1>
          <p className="text-gray-600">Este conteúdo pode ter sido arquivado ou não existe.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      <div className="container mx-auto px-4 py-8 lg:py-16">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
            {/* Left Column - Cover Image */}
            <div className="order-2 lg:order-1">
              <div className="relative">
                {settings.cover_image_url ? (
                  <img
                    src={settings.cover_image_url}
                    alt="Cover"
                    className="w-full h-auto rounded-2xl shadow-2xl"
                  />
                ) : (
                  <div className="w-full h-96 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl shadow-2xl flex items-center justify-center">
                    <div className="text-white text-center">
                      <h3 className="text-2xl font-bold mb-2">Imagem de Capa</h3>
                      <p>Configure no painel admin</p>
                    </div>
                  </div>
                )}
                
                {/* LIVE Badge */}
                <div className="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg">
                  OFERTA
                </div>
              </div>
            </div>

            {/* Right Column - Content */}
            <div className="order-1 lg:order-2 space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                  {settings.title || 'Título do Conteúdo'}
                  <span className="block text-orange-500">
                    {settings.subtitle || 'Subtítulo'}
                  </span>
                </h1>

                <p className="text-lg text-gray-600 leading-relaxed">
                  {settings.description || 'Descrição do conteúdo que será disponibilizado para download.'}
                </p>

                {settings.checklist_item && (
                  <div className="flex items-center gap-3 bg-orange-50 p-4 rounded-lg">
                    <ArrowRight className="w-5 h-5 text-orange-500" />
                    <span className="font-medium text-gray-900">
                      {settings.checklist_item}
                    </span>
                  </div>
                )}
              </div>

              {/* Email Capture Form */}
              <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
                <div className="text-center mb-6">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Download className="w-6 h-6 text-orange-500" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Informe seu e-mail para desbloquear
                  </h3>
                </div>

                {!submitted ? (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {error && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2 text-red-700">
                        <AlertCircle className="w-4 h-4" />
                        <span className="text-sm">{error}</span>
                      </div>
                    )}

                    <div className="flex gap-3">
                      <div className="flex-1 relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-colors"
                          placeholder="Digite seu melhor e-mail"
                          required
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={loading}
                        className="px-6 py-3 bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white font-semibold rounded-lg transition-colors duration-200"
                      >
                        {loading ? 'Enviando...' : 'Baixar grátis'}
                      </button>
                    </div>

                    <p className="text-xs text-gray-500 text-center">
                      Ao continuar, você concorda em receber nossos e-mails.
                    </p>
                  </form>
                ) : (
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                      <Check className="w-8 h-8 text-green-500" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">
                        Email registrado com sucesso!
                      </h4>
                      <p className="text-gray-600 mb-4">
                        Agora você pode baixar o conteúdo:
                      </p>
                      {settings.file_url ? (
                        <a
                          href={settings.file_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          download
                          className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-lg transition-colors"
                          onClick={(e) => {
                            // Debug information for production
                            console.log('=== DEBUG INFO ===')
                            console.log('Environment:', import.meta.env.MODE)
                            console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL)
                            console.log('File URL:', settings.file_url)
                            console.log('Short Code:', shortCode)
                            console.log('Settings ID:', settings.id)
                            console.log('==================')
                            
                            // Check if URL is accessible with more detailed error handling
                            fetch(settings.file_url, { 
                              method: 'HEAD',
                              mode: 'cors'
                            })
                              .then(response => {
                                console.log('File check response:', response.status, response.statusText)
                                if (!response.ok) {
                                  console.error('File not accessible:', {
                                    status: response.status,
                                    statusText: response.statusText,
                                    url: settings.file_url,
                                    headers: Object.fromEntries(response.headers.entries())
                                  })
                                  alert(`Erro: Ficheiro não está acessível (${response.status}). URL: ${settings.file_url}`)
                                  e.preventDefault()
                                }
                              })
                              .catch(error => {
                                console.error('Error checking file accessibility:', {
                                  error: error.message,
                                  url: settings.file_url,
                                  type: error.name
                                })
                                // Still allow download attempt
                                console.log('Allowing download attempt despite error...')
                              })
                          }}
                        >
                          <Download className="w-5 h-5" />
                          Baixar Arquivo
                        </a>
                      ) : (
                       <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                         <p className="text-yellow-800 font-medium mb-2">
                           ⚠️ Ficheiro não configurado
                         </p>
                         <p className="text-yellow-700 text-sm">
                           O administrador ainda não configurou o ficheiro para download. 
                           Entre em contacto para resolver este problema.
                         </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-4">
              {settings.logo_url && (
                <img
                  src={settings.logo_url}
                  alt="Logo"
                  className="h-8 w-auto"
                />
              )}
              <p className="text-sm text-gray-600">
                © 2025 Patrício Brito crIA. Todos os direitos reservados.
              </p>
            </div>

            {settings.instagram_url && (
              <a
                href={settings.instagram_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-600 hover:text-orange-500 transition-colors"
              >
                <Instagram className="w-5 h-5" />
                <span className="text-sm font-medium">Instagram</span>
              </a>
            )}
          </div>
        </div>
      </footer>
    </div>
  )
}