export interface Database {
  public: {
    Tables: {
      admin_settings: {
        Row: {
          id: string
          user_id: string
          name: string
          is_active: boolean
          short_code: string | null
          cover_image_url: string | null
          logo_url: string | null
          title: string | null
          subtitle: string | null
          description: string | null
          checklist_item: string | null
          file_url: string | null
          instagram_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name?: string
          is_active?: boolean
          short_code?: string | null
          cover_image_url?: string | null
          logo_url?: string | null
          title?: string | null
          subtitle?: string | null
          description?: string | null
          checklist_item?: string | null
          file_url?: string | null
          instagram_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          is_active?: boolean
          short_code?: string | null
          cover_image_url?: string | null
          logo_url?: string | null
          title?: string | null
          subtitle?: string | null
          description?: string | null
          checklist_item?: string | null
          file_url?: string | null
          instagram_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      leads: {
        Row: {
          id: string
          email: string
          settings_id: string
          created_at: string
        }
        Insert: {
          id?: string
          email: string
          settings_id: string
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          settings_id?: string
          created_at?: string
        }
      }
    }
  }
}